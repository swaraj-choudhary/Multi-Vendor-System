<!DOCTYPE html>
<head>
    <title>
        Shopkeeper Dashboard
   </title>
   <link rel="stylesheet" type="text/css" href="style.css">
   <meta charset="utf-8">
   <meta name="viewport" content ="width=device-width,intial-scale=1">
   <link rel="stylesheet" href="styles/style.css">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

</head>



<body>
    <div class="wrapper">
        <header>
            <div class=logo>
            <img  src="images/logo-small.png">
            <h1 style="color:rgb(7, 7, 7);font-size:25px">Product Management System</h1>
        </div>
            <nav>
                <ul>
                    <li><a href="Shop_index.php">Home</a></li>
                    <li><a href="Upload.php">Upload</a></li>
                    <li><a href="table.php">Product_Uploaded</a></li>
                    <li><a href="View_product.php">Product_View</a></li>
                    <li><a href="feedback.php">Contact</a></li>
                    <li><a href="feedback.php">FEEDBACK</a></li>
                </ul>
            </nav>
        </header>
        <section>
            <divclass="sec_img">
                <br><br><br>
            <div class="box">
                <h1 style="text-align:Center;font-size:35px;">WELCOME  TO THE SHOPS AREA</h1><br>
                <h1 style="text-align:left;font-size:20px;">OPENS AT:09:00am</h1><br>
                <h1 style="text-align:left;font-size:20px;">Closes AT:8:00pm</h1><br>
                </div>
            </div>

        </section>
        <footer>
            <p style ="color:white;text-align:center;font-size:25px;"><br>
            <br>
            Email:Mega_Store.com<br>
            Mobile:&nbsp +9674072127
        </p>


        </footer>
    </div>
</body>
