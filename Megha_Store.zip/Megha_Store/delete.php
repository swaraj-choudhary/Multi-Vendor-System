<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "crms";
$conn=mysqli_connect($servername, $username, $password, $dbname);
if($conn===FALSE){
   die('Connect Error (' . mysqli_connect_errno() . ') '. mysqli_connect_error());
}
$id=$_GET['id'];
 $sql = "DELETE FROM upload where id=$id";
$result1 = mysqli_query($conn, $sql);
if($result1)
{
	echo "<script type='text/javascript'>alert('Delete successfully');</script>";
	 echo "<script>window.location.href='table.php'</script>";
}
else
{
	echo"<font color='red'>faild"; 
}
?>