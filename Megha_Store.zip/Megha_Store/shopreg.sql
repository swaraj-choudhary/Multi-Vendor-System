-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 27, 2020 at 08:19 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crms`
--

-- --------------------------------------------------------

--
-- Table structure for table `shopreg`
--

CREATE TABLE `shopreg` (
  `id` int(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(200) NOT NULL,
  `gender` varchar(222) NOT NULL,
  `country` varchar(222) NOT NULL,
  `lnumber` varchar(200) NOT NULL,
  `anumber` int(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `dob` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `phone_no` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shopreg`
--

INSERT INTO `shopreg` (`id`, `first_name`, `last_name`, `email`, `gender`, `country`, `lnumber`, `anumber`, `address`, `dob`, `password`, `phone_no`) VALUES
(1, 'subhojit', 'dutta', 'subho@gmail.com', 'Male', 'India', '123456799', 123456789, 'kuyfuf;ff', '2020-04-27', '1234', 987456321),
(2, 'abhi', 'dutta', 'subhojitdutta1997@gmail.com', 'Male', 'India', '313', 3446, 'kjbkekfkLFE', '2020-04-04', '123456', 943376332);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `shopreg`
--
ALTER TABLE `shopreg`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `shopreg`
--
ALTER TABLE `shopreg`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
