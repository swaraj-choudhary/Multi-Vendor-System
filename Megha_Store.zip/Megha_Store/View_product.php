
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Shopping</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<link href="https://fonts.googleapis.com/css?family=Abril+fatface|Dancing+Script"rel="stylesheet">

</head>

<body class="container">
  <h1 class="text-center text-danger mb-5" style="font-family:'abril fatface',Cursive;">PRODUCTS AVAILABLE IN SHOPS 
  </h1>

  <div class="row">

  <?php

  $con =mysqli_connect('localhost','root');
  mysqli_select_db($con,'crms');
  if($con==True)
  {

  }
  else
  {
    echo "no connection";
  }
  $queryfire = mysqli_query($con,"select * from upload");
  $num = mysqli_num_rows($queryfire);


  if($num > 0){
    while($product = mysqli_fetch_assoc($queryfire)){
     ?>
    <div class="col-lg-3 col-md-3 col-sm-12">
      <form>
        <div class ="card" >
          <bold><h6 class ="Card-title bg-info text-white p-2 text-uppercase text-bold text-width-4"> <?php echo $product['product_name'];
           ?> </h6></bold>
          <div class="card-body"> 
            <img src="<?php echo $product['Image'];
           ?>" alt="phone" class="img-responsive" height='200' width='200'>

           <h6> &#8377; <?php echo $product['product_price']; ?><span>
           (<?php echo $product['product_details']; ?>% off)</span>
          </h6>
          <h6 class="badge badge-success">4.4 <i class="fa 
          fa-star"> </i></h6>
          <input type="text" name=" " class="form-control" placeholder="Quantity">


          </div>
          <div class="btn-group">
            <button class="btn btn-success" name="add" >Add to cart<a href="cart.php"></a></button>
            <button class="btn btn-warning">Buy now</button>
          </div>
        </div>
      </form>
    </div>

  <?php 
    }
  }
  ?>

</div>
</body>
</html>








