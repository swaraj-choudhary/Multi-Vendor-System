<?php 
$host='localhost';
$user='root';
$password='';
$dbname='crms';
//for connection
$conn=mysqli_connect($host, $user, $password, $dbname);
if($conn===FALSE){
   die('Connect Error (' . mysqli_connect_errno() . ') '. mysqli_connect_error());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css?family=Roboto:400,700" rel="stylesheet">
<title>Upload Your product Details</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<style type="text/css">
    body{
        color: #fff;
        background: #0eec484f;
        font-family: 'Roboto', sans-serif;
    }
    .form-control{
        height: 40px;
        box-shadow: none;
        color: #969fa4;
    }
    .form-control:focus{
        border-color: #5cb85c;
    }
    .form-control, .btn{        
        border-radius: 3px;
    }
    .signup-form{
        width: 400px;
        margin: 0 auto;
        padding: 30px 0;
    }
    .signup-form h2{
        color: #636363;
        margin: 0 0 15px;
        position: relative;
        text-align: center;
    }
    .signup-form h2:before, .signup-form h2:after{
        content: "";
        height: 2px;
        width: 30%;
        background: #d4d4d4;
        position: absolute;
        top: 50%;
        z-index: 2;
    }   
    .signup-form h2:before{
        left: 0;
    }
    .signup-form h2:after{
        right: 0;
    }
    .signup-form .hint-text{
        color: #999;
        margin-bottom: 30px;
        text-align: center;
    }
    .signup-form form{
        color: #999;
        border-radius: 3px;
        margin-bottom: 15px;
        background: #e4d172;
        box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
        padding: 30px;
    }
    .signup-form .form-group{
        margin-bottom: 20px;
    }
    .signup-form input[type="checkbox"]{
        margin-top: 3px;
    }
    .signup-form .btn{        
        font-size: 16px;
        font-weight: bold;      
        min-width: 140px;
        outline: none !important;
    }
    .signup-form .row div:first-child{
        padding-right: 10px;
    }
    .signup-form .row div:last-child{
        padding-left: 10px;
    }       0
    .signup-form a{
        color: #fff;
        text-decoration: underline;
    }
    .signup-form a:hover{
        text-decoration: none;
    }
    .signup-form form a{
        color: #5cb85c;
        text-decoration: none;
    }   
    .signup-form form a:hover{
        text-decoration: underline;
    }  
</style>
</head>
<body>

    <div class="row">
        <div class="col-lg-12">
            <div class="breadcrumb">
                <li class="active">
                    <l class="fa fa-dashboard"></l>
                    dashboard / Insert Product
                </li>
            </div>
        </div>
    </div><!--breadcrumb row End-->

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading"><!--panel heading start-->
                    <h3 class="panel-title"> 
                        <i class="fa a-money fa-w"></i> Insert Product
                    </h3>
                </div><!--panel heading ended-->
<div class="signup-form">
    <form action="" method="post" enctype = "multipart/form-data">
        <h2>Insert Product</h2>
        <p class="hint-text"></p>
        <div class="form-group">
             <?php
if(isset($_POST['submit']))
{ 
$shopkeeper_name = $_POST['shopkeeper_name'];
$product_id=$_POST['product_id'];
$product_name = $_POST['product_name'];
$product_price = $_POST['product_price'];
$product_quantity=$_POST['product_quantity'];
$date=$_POST['date'];
$product_details=$_POST['product_details'];
$filename=$_FILES["filebutton"]["name"];
$tempname=$_FILES["filebutton"]["tmp_name"];
$folder="Pictures/ ".$filename;
move_uploaded_file($tempname,$folder);
 $query="INSERT INTO upload( `shopkeeper_name`, `product_id`, `product_name`, `product_price`, `product_quantity`, `date`, `product_details`,`Image`) VALUES
     ('$shopkeeper_name','$product_id','$product_name','$product_price','$product_quantity','$date','$product_details','$folder')";
     mysqli_query($conn, $query) ; 
//echo "Connected successfully";
echo "<script type='text/javascript'>alert('upload successfully');</script>";
}
 
?>
            <div class="row">
                <div class="col-xs-6"><input type="text" class="form-control" name="shopkeeper_name" placeholder="shopkeeper_name" ></div>
                <div class="col-xs-6"><input type="text" class="form-control" name="product_id" placeholder="product_id" ></div>
            </div>          
        </div>
         <div class="form-group">
            <input type="text" class="form-control" name="product_name" placeholder="product_name" >
        </div>
        <div class="form-group">
            <input type="text" class="form-control" name="product_price" placeholder="product_price" >
        </div>
        <div class="form-group">
            <input type="text" class="form-control" name="product_quantity" placeholder="product_quantity" >
        </div>  
          <div class="form-group">
            <input type="text" class="form-control" name="date" placeholder="date" >
        </div>  
         <div class="form-group">
            <input type="text" class="form-control" name="product_details" placeholder="product_details" >
        </div>  

        <div class="form-group">
            <label for="filebutton">Upload picture</label>
             <input name="filebutton" class="input-file" id="filebutton" type="file">
        </div>


        <div class="form-group">
            <label class="checkbox-inline"><input type="checkbox" required="required"> I accept the everything right<a href="#">Terms of Use</a> &amp; <a href="#">Privacy Policy</a></label>
        </div>
        <div class="form-group">
            <button type="submit" name="submit" class="btn btn-success btn-lg btn-block">Upload Now</button>
        </div>
    </form>
    <div class="text-center">Want to Create Account <a href="login.php">Click Here</a></div>
</div>
</body>
</html>                            