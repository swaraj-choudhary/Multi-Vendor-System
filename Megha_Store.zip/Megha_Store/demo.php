
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IF=edge">
  <link rel="stylesheet" href="styles/style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="styles/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>

<body class="big-info">
	<div class="container">
		<div class="row">
			<div class="col-md-8 offset-md-2 bg-light p-4 mt-3 rounded">
				<h4 class="text-center">Search Products</h4>
				<form action="working.php" method="post" class="form-inline p-3">
					<input type="text" name="search" id="search" class="form-control form-control-lg rounded-0 border-info" placeholder="search..." style="width:80%;">
					<input type="submit" name="submit" value="Search" class="btn btn-info btn-lg rounded-0" style="width: 20%">
			</form>
		</div>
	<div class="col-md-5" style="position:relative;margin-top:-38px;
	margin-left: 215px;">
	<div class="list group" id="show-list">
	</div>
</div>
</div>
</div>

<script type="text/javascript">
$(document).ready(function(){
	$("#search").keyup(function(){
		var searchText = $(this).val();
		if(searchText!=''){
			$.ajax({
				url:'action.php',
				method:'post',
				data:{query:searchText},
				success:function(response){
					$('#show-list').html(response);
				}
			});
		}
		else{
			$("#show-list").html('');
		}
    });
	$(document).on('click','a',function(){
		$("#search").val($this).text());
        $("#show-list").html('');
    });
  });
 </script>
</body>


</html>

