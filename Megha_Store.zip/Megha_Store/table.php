<?php 
$host='localhost';
$user='root';
$password='';
$dbname='crms';
//for connection
$conn=mysqli_connect($host, $user, $password, $dbname);
if($conn===FALSE){
   die('Connect Error (' . mysqli_connect_errno() . ') '. mysqli_connect_error());
}
?>

<!DOCTYPE html>
<html>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link href="//cdn.datatables.net/plug-ins/f2c75b7247b/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet" id="bootstrap-css">
<link href="//cdn.datatables.net/responsive/1.0.4/css/dataTables.responsive.css" rel="stylesheet" id="bootstrap-css">
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="//cdn.datatables.net/1.10.5/js/jquery.dataTables.min.js"></script>
<script src="//cdn.datatables.net/plug-ins/f2c75b7247b/integration/bootstrap/3/dataTables.bootstrap.js"></script>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<style type="text/css">
<script src="//cdn.datatables.net/responsive/1.0.4/js/dataTables.responsive.js"></script>

<style type="text/css">
	body {
  font-size: 140%;
  color: #0D0D0D
}
h2 {
  text-align: center;
  padding: 20px 0;
}

table caption {
  padding: 0.5em 0;
}

table.dataTable th,
table.dataTable td {
  white-space: nowrap;
}

.p {
  text-align: center;
  padding-top: 140px;
  font-size: 14px;
}

</style>
<head>
	<title></title>
</head>

<body>

  <div class="row">
        <div class="col-lg-12">
            <div class="breadcrumb">
                <li class="active">
                    <l class="fa fa-dashboard"></l>
                    dashboard / Showing Details
                </li>
            </div>
        </div>
    </div><!--breadcrumb row End-->

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading"><!--panel heading start-->
                    <h3 class="panel-title"> 
                        <i class="fa a-money fa-w"></i> Product Details
                    </h3>
                </div><!--panel heading ended-->


	<h2>PRODUCT DETAILS </h2>

<div class="container">
  <div class="row">
    <div class="col-xs-12">
      <table summary="This table shows how to create responsive tables using Datatables' extended functionality" class="table table-bordered table-hover dt-responsive">
        
        <thead>
          <tr style="background-color:#F79E2C;">
            <th>Id</th>
            <th>shopkeeper name</th>
            <th>product id</th>
            <th>Product name</th>
            <th>product price</th>
            <th>product quantity</th>
            <th>product details</th>
            <th>Image details</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody style="background-color:#A6ECE4;">
        	 <?php
   $sql=mysqli_query($conn,"select * from upload");
while($row = mysqli_fetch_array($sql)){
  ?>
          <tr>
          	<td><?php echo $row['id'];?></td>
            <td><?php echo $row['shopkeeper_name'];?></td>
            <td><?php echo $row['product_id'];?></td>
            <td><?php echo $row['product_name'];?></td>
            <td><?php echo $row['product_price'];?></td>
            <td><?php echo $row['product_quantity'];?></td>
            <td><?php echo $row['product_details'];?></td>
            <td><?php <img src="<?= $row['Image'] ?>">?></td>
             <td><a href="edit.php?id=<?php echo $row['id'];?>"> 
          <span class="glyphicon glyphicon-pencil"></span> edit 
        </a> </td>
   			 <td><center><a href="delete.php?id=<?php echo $row['id'];?>">
          <span class="glyphicon glyphicon-trash"></span>
        </a></center></td>
          </tr>
          <?php }?>
        </tbody>
        <tfoot>
          <tr>
            <td colspan="5" class="text-center"> <a href="http://www.infoplease.com/ipa/A0855611.html" target="_blank"></a>  <a href="http://www.worldometers.info/world-population/population-by-country/" target="_blank"></a>.</td>
          </tr>
        </tfoot>
      </table>
    </div>
  </div>
</div>
</body>
<script type="text/javascript">
	$('table').DataTable();
</script>


</html>





