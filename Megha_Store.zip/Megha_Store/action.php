<?php 
$host='localhost';
$user='root';
$password='';
$dbname='crms';
//for connection
$conn=mysqli_connect($host, $user, $password, $dbname);
if($conn===FALSE){
   die('Connect Error (' . mysqli_connect_errno() . ') '. mysqli_connect_error());
}

	if(isset($_POST['query'])){
	$inpText=$_POST['query'];
	$query ="SELECT product_name FROM upload WHERE product_name LIKE '%$inpText%'";
	$result = $conn->query($query);
	if($result->num_rows>0){
		while($row=$result->fetch_assoc()){
		 echo "<a href='#' class='list-group-item list-group-item-action border-1'>".$row['product_name']."</a>";
		}
	}
	else
	{
		echo "<p class='list-group-item border-1'>No Record</p>";
	}
}
?>

