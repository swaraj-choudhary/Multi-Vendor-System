<?php

$trade_name=$_REQUEST['trade_name'];
echo "$trade_name is a new subject";

?>