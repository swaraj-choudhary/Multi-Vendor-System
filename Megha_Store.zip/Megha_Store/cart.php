<!DOCTYPE html>
<head>
    <title>
         products Cart page
   </title>
   <link rel="stylesheet" type="text/css" href="style.css">
   <meta charset="utf-8">
   <meta name="viewport" content ="width=device-width,intial-scale=1">
   <link rel="stylesheet" href="styles/style.css">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body>
<div class="container">
	<div class="row justify content center">
		<div class="col-lg-10">
			<div class="table responsive mt-2">
				<table class="table table-bordered table-stripped text-center">
          <thead>
					<tr>
						<td colspan="7">
							<h4 class="text-center text-info m-0">Items to Purchase  are in Cart!</h4>
						</td>
					</tr>
					<tr>
						<th>ID</th>
						<th>Product Name</th>
						<th>Image</th>
						<th>Price</th>
						<th>Quantity</th>
						<th>Total Price</th>
						<th>
							<a href="perform.php?clear=all" class="badge-danger badge p-1" onclick="return confirm('Are you ready to remove?');"><i class="fas fa-trash"></i>&nbsp;&nbsp;Clear Cart</a>
						</th>
					</tr>
        </thead>
        <tbody>
        	<?php 
$host='localhost';
$user='root';
$password='';
$dbname='crms';
//for connection
$conn=mysqli_connect($host, $user, $password, $dbname);
if($conn===FALSE){
   die('Connect Error (' . mysqli_connect_errno() . ') '. mysqli_connect_error());
}

$stmt = $conn->prepare("SELECT * FROM cart");
$stmt ->execute();
$result =$stmt->get_result();
$grand_total=0;
while($row = $result->fetch_assoc()):
?>
<tr>
	<td><?=$row['id']?></td>
	<td><?=$row['product_name'] ?></td>
	<td><img src="<?= $row['Image'] ?>" width='50'></td>
	<td><i class="fas fa-rupee-sign"></i>&nbsp;&nbsp;<?=number_format($row['product_price'],2); ?></td>
	<td><input type="number" class="form-control itemQty" value="<?= $row['qty'] ?>" style="width:75px;"></td>
	<td><i class="fas fa-rupee-sign"></i>&nbsp;&nbsp;<?= number_format($row['total_price'],2); ?></td>
	<td >
		<a href="Demo_search.php?remove=<?= $row['id'] ?>" class="text-danger lead" onclick="return confirm('Are you sure you want to remove the item?');"><i class="fas fa-trash-alt"></i> Delete</a>
	</td>
</tr>
<?php $grand_total +=$row['total_price']; ?>
<?php endwhile; ?>
<tr>
	<td colspan="3">
		<a href="View_product.php" class="btn btn-success"> <i class="fas fa-cart-plus"></i>&nbsp;&nbsp;Continue Shopping</a> 
	</td>
	<td colspan="2"><b>Grand Total</b></td>
	<td><b><?= $grand_total ?></b></td>
	<td>
		<a href="checkout.php" class="btn btn-info <?= ($grand_total>1)?" ":"disabled"; ?>">Checkout</a>
	</td>
</tr>
</tbody>
</table>
			</div>
		</div>
	</div>
</div>

</body>
</html>


