<?php 
$host='localhost';
$user='root';
$password='';
$dbname='crms';
//for connection
$conn=mysqli_connect($host, $user, $password, $dbname);
if($conn===FALSE){
   die('Connect Error (' . mysqli_connect_errno() . ') '. mysqli_connect_error());
}


	if(isset($_POST['submit'])){
	$data=$_POST['search'];
	$sql="SELECT * FROM upload WHERE product_name= '$data'";
	$result=$conn->query($sql);
	$row=$result->fetch_assoc();
	print_r($row);


	echo "id :".$row['id']."<br>";
	echo " In Shop :".$row['shopkeeper_name']."<br>";
	echo "Product details :".$row['product_details']."<br>";
	echo "product_name :".$row['product_name']."<br>";
	echo "Price of item: ".$row['product_price']."<br>";
}
?>