<?php 
$host='localhost';
$user='root';
$password='';
$dbname='crms';
//for connection
$conn=mysqli_connect($host, $user, $password, $dbname);
if($conn===FALSE){
   die('Connect Error (' . mysqli_connect_errno() . ') '. mysqli_connect_error());
}
?>

<!DOCTYPE html>
<html>
<head>
<style>
* {
  box-sizing: border-box;
}

input[type=text], select, textarea {
  width: 75%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
}

label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: 90%;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 15px;
  background-color: #f2f2f2;
  padding: 20px;
}

.col-25 {
  float: left;
  width: 20%;
  margin-top: 6px;
}

.col-75 {
  float: left;
  width: 55%;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 50%;
    margin-top: 0;
  }
}
</style>
</head>
<body>

<h2><center>Edit details Form</center></h2>
<?php
$id=$_GET['id'];
$m=mysqli_query($conn,"select * from upload Where id='$id'");
  $check=mysqli_fetch_array($m);
if(isset($_POST['submit']))
{
$shopkeeper_name=$_POST['shopkeeper_name'];
$product_name=$_POST['product_name'];
$product_price=$_POST['product_price'];
$product_quantity=$_POST['product_quantity'];
$product_details=$_POST['product_details'];
 $edit=("UPDATE `upload` SET `shopkeeper_name`='".$shopkeeper_name."',`product_name`='".$product_name."',`product_price`='".$product_price."',`product_quantity`='".$product_quantity."',`product_details`='".$product_details."', WHERE id='$id' ");
  if (mysqli_query($conn, $edit)) {
    

      echo "<script type='text/javascript'>alert('Update successfully');</script>";
   echo "<script>window.location.href='table.php'</script>";
}}
    
?>
<div class="container">
  <form >
  <div class="row">
    <div class="col-25">
      <label for="fname">shopkeeper_name</label>
    </div>
    <div class="col-75">
      <input type="text" value="<?php echo $check['shopkeeper_name'];?>" name="shopkeeper_name">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="lname">product_name</label>
    </div>
    <div class="col-75">
      <input type="text" value="<?php echo $check['product_name'];?>"  name="product_name" >
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="lname">product_price</label>
    </div>
    <div class="col-75">
      <input type="text" value="<?php echo $check['product_price'];?>"  name="product_price">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="lname">product_quantity</label>
    </div>
    <div class="col-75">
      <input type="text" value="<?php echo $check['product_quantity'];?>"  name="product_quantity" >
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="lname">product_details</label>
    </div>
    <div class="col-75">
      <input type="text" value="<?php echo $check['product_details'];?>"  name="product_details" >
    </div>
  </div>
 <br>
  <div class="row">
    <input type="submit" name=submit value="Submit">
  </div>
 
  </form>
</div>

</body>
</html>
