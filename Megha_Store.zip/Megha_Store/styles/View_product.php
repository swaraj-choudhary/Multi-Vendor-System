
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<link href="https://fonts.googleapis.com/css?family=Abril+fatface|Dancing+Script"rel="stylesheet">

</head>

<body class="container">
	<h1 class="text-center text-danger mb-5" style="font-family:'abril fatface',Cursive;">Online Shopping cart
	</h1>

	<div class="row">

	<?php

	$con =mysqli_connect('localhost','root');
	mysqli_select_db($con,'crms');
	if($con==True)
	{
		echo "connection succesful";
	}
	else
	{
		echo "no connection";
	}

	$query = "SELECT `id`, `Name`, `Image`, `Price`, `Discount` FROM `product_view` order by id ASC";

	$queryfire = mysqli_query($con,$query);
	$num = mysqli_num_rows($queryfire);


	if($num > 0){
		while($product = mysqli_fetch_assoc($queryfire)){
		 ?>
		<div class="col-lg-3 col-md-3 col-sm-12">
			<form>
				<div class ="card" >
					<h6 class ="Card-title"> <?php echo $product['Name'];
					 ?> </h6>
					<div class="card-body"> 
						<img src="<?php echo $product['Image'];
					 ?>" alt="phone" class="img-fluid">
					</div>
				</div>
			</form>
		</div>

	<?php	
		}
	}
	?>

</div>
</body>
</html>








